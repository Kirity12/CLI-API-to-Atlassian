# Trello CLI API

This Command Line Interface (CLI) tool allows you to interact with Trello boards, cards, labels, and columns. You can create new cards, add labels to cards, create new labels, and perform various other operations on your Trello boards, all from the command line.

## Features

- Create new cards on Trello boards.
- Add labels to cards.
- Create new labels in a Trello board.
- Retrieve information about boards, columns, cards, and labels.
- Perform read and write operations on Trello boards.

## Getting Started

To get started with the Trello CLI, follow these steps:

1. Navigate to the project directory

### Installation